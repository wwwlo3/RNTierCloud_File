import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

d = webdriver.Chrome('./chromedriver')

d.get('https://www.naver.com')

utag = d.find_element_by_id('query')
utag.send_keys('파이썬')
utag.send_keys(Keys.RETURN)
time.sleep(3)

div_tag = d.find_element_by_class_name('_svp_list')
ultag = div_tag.element_by_class_name('svp_item')

d.close()
d.quit()