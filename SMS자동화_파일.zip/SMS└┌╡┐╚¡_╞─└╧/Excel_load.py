from openpyxl import Workbook
from openpyxl import load_workbook

# cb = Workbook() # 클루닉스 워크북
# cs = cb.create_sheet('data')

# cs['A1'].value = 'DATA1'
# cs['A2'].value = 'DATA2'
# cs['A3'].value = 'DATA3'

# cb.save('result.xlsx')

# cb = Workbook() # 클루닉스 워크북
# cs = cb.active

# for row in range(10):
#     cs.append([row, row+100])
# cb.save('result.xlsx')

cl = load_workbook('sample_list.xlsx', read_only=True) # Clunix 고객 명단 file 오픈
cs = cl['Worksheet']

print(cs['B1'].value) # 사용자 명
print(cs['C1'].value) # 사용자 ID 
print(cs['K1'].value) # 카드 등록 여부
print(cs['H1'].value) # 가입일 
print(cs['O1'].value) # 휴대폰  

for row in cs.iter_rows():
    #print(row[0].value)
    if row[1].value =='김재호':
        print(row[1].value)
        print(row[10].value)
        break

# cells = cs['B1:D4']
# for row in cells:
#     for cell in row:
#         print(cell.value)
# cells = cs['B']
# # 튜플 형식으로 출력
# for cell in cells:
#     print(cell.value)
